import contextlib,json,sys
from pathlib import Path
PM=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(PM/'acceptance'),str(PM/'cfd_simulator'),str(PM/'ipbus_adc'),'/home/codex-hil/FIT_PM_FW_uPC/tools/hardware','/home/codex-hil/kasli-phase-tester']
from lease import acquire
from station import console
from console import ConsoleI2C,Registers
from mcp23017 import afe_route
from pm12_console_regression import capture
from pm12_power import require_power_good
from mod_dac28 import DAC,remote_lease
from phase_scan import ConsoleDAC
from client import Client
from host.gate_phase_ipbus import GatePhaseIPbusDevice
base=Path('/srv/codex-hil-nvme/pm12-ch01-20261118');cfg=json.loads((base/'station.json').read_text());r={'scope':'Final analog inhibition and baseline, no programming','gpio':{},'phase_uart':[]}
with contextlib.ExitStack() as st:
 for n in sorted(cfg['run_leases']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 u=st.enter_context(console(cfg));r['power']=require_power_good(u,capture)
 c=Client();st.callback(c.close);r['fpga']=c.read(0,3);assert r['fpga']==[0x504d1202,0x10002,0xff2f746c]
 bus=ConsoleI2C(u,capture)
 for ch in [1,2,3,4]:
  with bus.routed(*afe_route(ch)):
   regs=Registers(bus);assert regs.read(10)==regs.read(11) and not regs.read(10)&128
   regs.write(0x14,regs.read(0x14)|0x88);regs.write(0x15,regs.read(0x15)|0x20)
   assert regs.read(0x12)&0x88==0x88 and regs.read(0x13)&0x20
   r['gpio'][str(ch)]={str(a):regs.read(a) for a in [0,1,0x12,0x13,0x14,0x15]}
 phase=ConsoleDAC(u,1,capture,r['phase_uart'].append);phase.set_code(0);r['phase_code_final']=0
 remote=st.enter_context(remote_lease());dac=DAC(remote,channels=[0,1]);st.callback(dac.close);dac.park(1,1);dac.channels=(2,3);dac.park(1.024,2.048);r['dac_final']=dac.snapshot();r['scpi']=dac.records
 r['tca_final']={str(a):bus.mux(a) for a in [0x70,0x71]};assert set(r['tca_final'].values())=={0}
 d=GatePhaseIPbusDevice();st.callback(d.close);r['hdmi']=[d.read(0x144),d.read(0x150)];assert r['hdmi'][0]==1 and r['hdmi'][1]&0xd==9
 r['power_final']=require_power_good(u,capture);r['i2c']=bus.records;r['pass_']=True
(base/'final-safe.json').write_text(json.dumps(r,indent=2)+'\n');print('FINAL_ANALOG_SAFE')
