import contextlib,json,sys,subprocess
from pathlib import Path
PM=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(PM/'acceptance'),str(PM/'cfd_simulator'),'/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire
from station import console
from console import ConsoleI2C,Registers
from mcp23017 import afe_route
from pm12_console_regression import capture
from pm12_power import require_power_good
from mod_dac28 import DAC,remote_lease
base=Path('/srv/codex-hil-nvme/pm12-ch01-20261118');cfg=json.loads((base/'station.json').read_text())
with contextlib.ExitStack() as st:
 for name in sorted(cfg['run_leases']):st.enter_context(acquire(Path.home()/'.cache'/(name+'.lock')))
 u=st.enter_context(console(cfg));r=dict(power=require_power_good(u,capture));bus=ConsoleI2C(u,capture)
 for ch in [1,2,3,4]:
  with bus.routed(*afe_route(ch)):
   regs=Registers(bus);assert regs.read(0x12)&0x88==0x88,'Amps/monitor must be inhibited before ADC-only parking'
 remote=st.enter_context(remote_lease());dac=DAC(remote,channels=[2,3]);st.callback(dac.close);r['before']=dac.snapshot();dac.park(2.048,1.024);r['after']=dac.snapshot();r['scpi']=dac.records
(base/'adc-standard-parking.json').write_text(json.dumps(r,indent=2)+'\n')
cmd=['/home/codex-hil/kasli-diot-bringup/.venv/bin/python',str(PM/'cfd_simulator/adc_line_test.py'),'--acquire','--afe','1','--points','257','--span','1.2','--board-serial','1803','--expected-build','ff2f746c','--dac-channels','0','1','--integrator-dac-channels','2','3','--out',str(base/'adc-lines-standard')]
(base/'adc-standard-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (base/'adc-lines-standard-console.txt').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
