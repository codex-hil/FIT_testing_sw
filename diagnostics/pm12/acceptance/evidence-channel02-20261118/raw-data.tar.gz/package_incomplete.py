from pathlib import Path
import json,shutil,hashlib,tarfile,datetime
p=Path(__file__).resolve().parent;repo=Path('/home/codex-hil/fit-testing-publish');e=repo/'diagnostics/pm12/acceptance/evidence-channel02-20261118';e.mkdir(exist_ok=False)
safe=json.loads((p/'final-safe.json').read_text());assert safe['pass_'];analysis=json.loads((p/'incomplete-analysis.json').read_text());s={'board_uid':'PM12-K7-3A17A1B402212223','physical_channel':2,'date':'2026-11-18','adc_status':'INCOMPLETE','attempts':analysis,'route_verified':True,'final_safe':True,'cpld_programmed':False,'qualification_changed':False,'integrator_repeated':False};(e/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
for n in ['route-validation.json','acquisition-attempts.json','incomplete-analysis.json','final-safe.json','adc2-incomplete.png','adc2-incomplete.pdf','analyze_incomplete.py']:shutil.copy2(p/n,e/n)
files=[f for f in p.rglob('*') if f.is_file() and 'jtag-work' not in f.parts and '__pycache__' not in f.parts and 'NOT_EXECUTED' not in f.name];m={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files};(e/'raw-manifest.json').write_text(json.dumps(m,indent=2)+'\n');a=e/'raw-data.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(a,'r:gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'archive-sha256.txt').write_text(hashlib.sha256(a.read_bytes()).hexdigest()+'  raw-data.tar.gz\n')
(e/'README.md').write_text('''# Channel2 ADC — 18 November2026 — INCOMPLETE

Board PM12-K7-3A17A1B402212223, MCU1803; CFD03 on physical PM2. Fresh FPGA DNA/MCU/IPbus identity bound to batch ch01-04-attempt003. Both USB declared moved to2; active/inhibited probes verify DAC01→J8 on2. DAC23/J6 was not exercised this turn.

ADC reacts normally to the differential stimulus: active slopes approximately−1777/−1789code/V versus inhibited+6.7/+3.7code/V. Full257-level/bank scans cannot be qualified: unchanged two-sample stability validation stopped all three attempts. Phase0:103completed buffers, next A buffer3unstable positions (D2). Phase32768:390completed buffers (full A), next B buffer4unstable positions (D6). Phase16384:164completed buffers, next A buffer3unstable positions (D6). These are XOR differences between consecutive selected samples, not proof of a short or identified hardware cause.

No unstable samples were removed, no partial scans merged, no decoder thresholds changed, no failed run marked PASS. No full bit/adjacent-pair acceptance or ADC2 campaign selection was made. Raw failed buffers and all successful partial captures are preserved. Plots show partial mean response only. Phase0/32768/16384 are separately labelled; timing margin remains unresolved.

Previous channel2 integrator diagnostics remain unchanged. No CPLD/FPGA/MCU programming, PLL profile change, SMU/TDC repeat or production PDF generation. Final phase0, DAC01=1/1V,23=1.024/2.048V; fitted1–4 amps/bypass/monitors inhibited, muxes0, Kasli outputs retained. All archive files were read back and SHA256 verified.

![Partial ADC scans, not qualification](adc2-incomplete.png)
''')
prefix='Latest channel2 ADC (2026-11-18): INCOMPLETE. Correct J8 response verified; full acquisitions at phase0/32768/16384 stop on two-sample stability. No ADC2 PASS or bit-test acceptance, no qualification changes. Raw failures retained; final baseline restored, no CPLD programming.\n[Channel2 evidence](LINK).\n\n'
for path,link in [(repo/'README.md','diagnostics/pm12/acceptance/evidence-channel02-20261118/README.md'),(repo/'diagnostics/pm12/acceptance/ACTIVE_CAMPAIGN.md','evidence-channel02-20261118/README.md')]:path.write_text(prefix.replace('LINK',link)+path.read_text())
a=Path('/srv/codex-hil-nvme/pm12-campaigns/active.json');d=json.loads(a.read_text());d['status']='ADC2 INCOMPLETE: stability errors at phase0/32768/16384. No qualification changes. Baseline restored, no programming.';d['latest_results']=s;d['latest_evidence']=str(e);d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['verified_connections']={'ADC':'DAC01/J8 on2 active/inhibited verified','integrator':'DAC23/J6 on2 owner-declared; not exercised this turn'};a.write_text(json.dumps(d,indent=2)+'\n')
h=Path('/home/codex-hil/FIT_PM_FW_uPC/docs/pm12_current_hardware_state.md');h.write_text(prefix.replace('LINK',str(e/'README.md'))+h.read_text());print('Verified archive:',len(files),'files;',a)
