from pathlib import Path
import json,hashlib,tarfile,shutil,datetime
p=Path(__file__).resolve().parent;repo=Path('/home/codex-hil/fit-testing-publish');e=repo/'diagnostics/pm12/acceptance/evidence-integrator03-20261119';e.mkdir(exist_ok=False)
s=json.loads((p/'final/summary.json').read_text());safe=json.loads((p/'final-safe.json').read_text());assert s['status']=='PASS_FUNCTIONAL' and safe['pass_'];assert all(x['run']=='coarse' and x['error']=='ADC rail/near-rail sample' for x in s['analysis_rejected'])
for n in ['final','fine-analysis','regression-channel1']:shutil.copytree(p/n,e/n)
for n in ['fine-command.json','validation-command.json','analysis-frozen-before-validation.json','final-safe.json','regression-console.txt']:shutil.copy2(p/n,e/n)
shutil.copy2(repo/'diagnostics/pm12/cfd_simulator/analyze_reset_reference.py',p/'executed-analysis.py')
files=[f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts];m={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files};(e/'raw-manifest.json').write_text(json.dumps(m,indent=2)+'\n');a=e/'raw-data.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(a,'r:gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'archive-sha256.txt').write_text(hashlib.sha256(a.read_bytes()).hexdigest()+'  raw-data.tar.gz\n')
(e/'README.md').write_text('''# PM3 integrator repeat — 19 November2026

Board PM12-K7-3A17A1B402212223, MCU1803, resident FPGAff2f746c, fitted CFDs1–4; CFD02 on PM3. Owner moved DAC to3; both USB inferred from preceding instruction. This acquisition independently verifies DAC23/J6 on3 by signed response; DAC01/J8 was not exercised, previous ADC3 qualification retained.

Integrator A/B PASS_FUNCTIONAL with nominal20MHz gates, legacy before-str raw decoding and phaseDAC0. Initial str-rise/32768 attempt failed disabled-control data stability before any stimulus points; retained. Phase probe then found all30enabled baseline buffers coherent under legacy policy across five phase codes; restored0. Complete coarse40/fine328/validation64 transfer buffers were coherent under the selected phase0 policy. Fine and validation buffers unclipped; four coarse B/+20mV buffers clipped and excluded explicitly.

Fine P-only41points,3..7mV at100µV command steps with DAC3fixed2.048V. A candidate delta4.6mV: DAC2=1.0286V; independent returns−0.000073/−0.141code. B delta5.7mV: DAC2=1.0297V; returns+0.316/+0.064code. ±5mV responses A+11.87/−12.10code, B+11.18/−12.36code. All satisfy abs(return)<=2codes and opposite signs beyond±4codes. Fits A−2438.88/B−2220.34code/V. These are independently selected per-bank balance points, not one simultaneous A/B null or calibrated current null.

Generalized reset-reference analysis seeds only an unambiguous positive integration pair above both reset samples under−20mV stimulus, matches−10mV reset reference, calibrates reset levels using fine sweep alone and checks independent validation afterward. This handles PM3 A's large integration/reset DC separation without incorrectly selecting the reset-release jump as integration. Same RMS<=5code and separation>=3code guards retained. Exact model/source frozen before independent validation. Replay on PM1 reproduces prior fit and validation values exactly. Integration raw decoder window is explicit in scan metadata and analysis; historical defaults unchanged.

This is separate diagnostic functional evidence, not retroactive selection under the older sealed integrator campaign contract. No source or raw evidence from earlier attempts altered. No CPLD/FPGA/MCU programming, PLL profile change, SMU/TDC/ADC-transfer repeat or production PDF generation. Final phase0, DAC01=1/1V,23=1.024/2.048V; all fitted1–4 amps/bypass/monitors inhibited, TCA0; Kasli outputs retained. Archive read-back SHA256 verified.

![Integrator3 balance and checks](final/integrator3.png)
''')
prefix='Latest PM3 integrator repeat (2026-11-19): A/B PASS_FUNCTIONAL at nominal20MHz, phase0/before-str.100µV fine scan, independent returns and±5mV controls pass; four clipped coarse buffers excluded explicitly. Separate reset-reference diagnostic method, old selections unchanged. Final baseline restored, no CPLD changes. Integrators4/6 remain unresolved.\n[PM3 integrator evidence](LINK).\n\n'
for f,link in [(repo/'README.md','diagnostics/pm12/acceptance/evidence-integrator03-20261119/README.md'),(repo/'diagnostics/pm12/acceptance/ACTIVE_CAMPAIGN.md','evidence-integrator03-20261119/README.md'),(Path('/home/codex-hil/FIT_PM_FW_uPC/docs/pm12_current_hardware_state.md'),str(e/'README.md'))]:f.write_text(prefix.replace('LINK',link)+f.read_text())
f=Path('/srv/codex-hil-nvme/pm12-campaigns/active.json');d=json.loads(f.read_text());d['status']='PM3 integrators A/B PASS_FUNCTIONAL in diagnostic reset-reference method. Final baseline restored, no programming. Integrators4/6 unresolved.';d['latest_evidence']=str(e);d['latest_results']={'integrator_status':s['status'],'fits':s['fits'],'validation':s['validation'],'old_selections_changed':False};d['verified_connections']={'integrator':'DAC23/J6 verified on3 by signed response','ADC':'DAC01/J8 on3 assumed, not tested this turn'};d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();f.write_text(json.dumps(d,indent=2)+'\n');print('verified archive',len(files))
