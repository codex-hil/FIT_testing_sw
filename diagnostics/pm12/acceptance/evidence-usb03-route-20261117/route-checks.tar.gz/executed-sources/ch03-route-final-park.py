from pathlib import Path
import sys,json,contextlib,datetime
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance'),str(P/'cfd_simulator')]
from lease import acquire
from mod_dac28 import remote_lease,DAC
root=Path(__file__).parent.parent;w=root/'batches/ch01-04-attempt001/working/ch03'
with contextlib.ExitStack()as st:
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001','esp32-6825dd4c49e4','lattice-VER00001']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 remote=st.enter_context(remote_lease());d=DAC(remote,channels=[2,3]);st.callback(d.close);d.park(1.024,2.048);r=dict(pass_=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),setpoints=d.snapshot(),scpi=d.records,note='Only restore DAC23 to previous safe park; no GPIO/Kasli/clock/FPGA changes. Native route probes restored bypass/monitor inhibits.')
(w/'route-final-park.json').write_text(json.dumps(r,indent=2)+'\n')
print('FINAL_PARK_PASS',flush=True)
