from pathlib import Path
import json,tarfile,hashlib,shutil,datetime
p=Path(__file__).resolve().parent;repo=Path('/home/codex-hil/fit-testing-publish');e=repo/'diagnostics/pm12/acceptance/evidence-adc02-timing-20261118';e.mkdir(exist_ok=False)
sources=p/'sources';sources.mkdir(exist_ok=True)
for rel in ['cfd_simulator/adc_dc_scan.py','cfd_simulator/mod_dac28.py','cfd_simulator/phase_scan.py','cfd_simulator/console.py','cfd_simulator/mcp23017.py','ipbus_adc/adc_decode.py','ipbus_adc/capture.py','ipbus_adc/client.py','adc/cpld/adc_mux.vhd','acceptance/station.py','acceptance/lease.py']:
 target=sources/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'diagnostics/pm12'/rel,target)
for n in ['summary.json','historical-windows.json','timing-diagnostic.png','timing-diagnostic.pdf','analyze.py','summarize.py','acquire_diagnostic.py','final-safe.json','frozen-analysis-sha256.json']:shutil.copy2(p/n,e/n)
# Original failed buffers retained explicitly, in addition to their earlier sealed archive.
old=Path('/srv/codex-hil-nvme/pm12-ch02-20261118');hist=json.loads((p/'historical-windows.json').read_text());original=p/'original-failures';original.mkdir()
for name in hist:shutil.copy2(old/name,original/(Path(name).parents[1].name+'-'+Path(name).name))
files=[f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts];m={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files};(e/'raw-manifest.json').write_text(json.dumps(m,indent=2)+'\n');a=e/'raw-data.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(a,'r:gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'archive-sha256.txt').write_text(hashlib.sha256(a.read_bytes()).hexdigest()+'  raw-data.tar.gz\n')
(e/'README.md').write_text('''# ADC2 timing diagnostic — 18 November2026

DUT PM12-K7-3A17A1B402212223, MCU1803, FPGAff2f746c. ADC channel2 remains INCOMPLETE in production campaign. No gateware/MCU/CPLD programming or PLL profile change; no original decoder or qualification criteria modified.

Original three rejected buffers show isolated D2/D6 settling one FPGA sample later than the old two-samples-before-STR condition expects. At those exact events the pair ending at STR rise agrees. The capture implementation uses MultiReg on the14-bit raw bus; CPLD mux source forwards selected ADC and CLK80 as DV. Source copies are contextual evidence, not a new resident-build equivalence proof.

Fresh144buffers: phase codes0/16384/32768, both banks, differential inputs−0.234375/+0.046875/+0.3375V,8repeats each. Every raw buffer retained; all five temporal windows compared. Original decoder failures were counted, never suppressed or marked PASS. Analysis source frozen before acquisition.

| Phase | Bank | Unequal old pairs(-2,-1) | Unequal later pairs(-1,0) |
|---|---|---:|---:|
|0|A|434|257|
|0|B|0|604|
|16384|A|90|0|
|16384|B|2042|0|
|32768|A|0|0|
|32768|B|5|0|

For phases16384/32768 the later pair has0disagreements over98112checked pairs,96buffers. Phase0 is not a common valid sampling window. These observations favor phase-dependent sampling/window selection over a persistent stuck/shorted data line. They do not certify physical setup/hold margins, identify a faulty device, or establish full-range ADC qualification. An alternative decode policy needs explicit timing validation and a separate protocol version before use in production acceptance; simply ignoring early mismatches is insufficient.

Acquisition completed144buffers before a redundant inhibit callback erroneously ran after its I2C route had closed (NACK). Routed inhibit had already completed. Independent final cleanup returned0 and verified phase0, DAC01=1/1V,23=1.024/2.048V, fitted1–4 amps/bypass/monitor inhibition and TCA0. Shared Kasli outputs unchanged. The acquisition wrapper exits nonzero for that cleanup-callback error; it is recorded rather than hidden. Current script is the exact executed source.

Raw archive includes144newbuffers, original3failed buffers, logs and source snapshots. All files read-back SHA256 verified. No PDF production report generated.

![Timing comparison](timing-diagnostic.png)
''')
prefix='Latest ADC2 timing diagnostic (2026-11-18):144buffers retained. At phase16384/32768, pair ending at STR rise has0disagreements/98112pairs; old earlier pair still fails. Phase0 has no shared clean window. Evidence favors timing/window selection; no hardware fault or production PASS established. Baseline restored, no programming.\n[Timing diagnostic](LINK).\n\n'
for f,link in [(repo/'README.md','diagnostics/pm12/acceptance/evidence-adc02-timing-20261118/README.md'),(repo/'diagnostics/pm12/acceptance/ACTIVE_CAMPAIGN.md','evidence-adc02-timing-20261118/README.md'),(Path('/home/codex-hil/FIT_PM_FW_uPC/docs/pm12_current_hardware_state.md'),str(e/'README.md'))]:f.write_text(prefix.replace('LINK',link)+f.read_text())
f=Path('/srv/codex-hil-nvme/pm12-campaigns/active.json');d=json.loads(f.read_text());d['latest_diagnostic']=str(e);d['status']='ADC2 remains INCOMPLETE;144buffer diagnostic favors sampling window/phase issue. Baseline restored, no programming.';d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();f.write_text(json.dumps(d,indent=2)+'\n');print('archive verified',len(files))
