import subprocess,json
from pathlib import Path
p=Path(__file__).resolve().parent
with (p/"fine-console.txt").open("w") as f:subprocess.run(json.loads((p/"fine-command.json").read_text()),stdout=f,stderr=subprocess.STDOUT,check=True)
