import subprocess,json
from pathlib import Path
p=Path(__file__).resolve().parent
with (p/"validation-console.txt").open("w") as f:subprocess.run(json.loads((p/"validation-command.json").read_text()),stdout=f,stderr=subprocess.STDOUT,check=True)
