from pathlib import Path
import json,hashlib,tarfile,shutil,datetime
p=Path(__file__).resolve().parent;repo=Path('/home/codex-hil/fit-testing-publish');e=repo/'diagnostics/pm12/acceptance/evidence-integrator04-20261119';e.mkdir(exist_ok=False)
s=json.loads((p/'final/summary.json').read_text());safe=json.loads((p/'final-safe.json').read_text());assert s['status']=='PASS_FUNCTIONAL' and safe['pass_'] and not s['analysis_rejected']
for n in ['final','fine-analysis']:shutil.copytree(p/n,e/n)
for n in ['fine-command.json','validation-command.json','analysis-frozen-before-validation.json','final-safe.json']:shutil.copy2(p/n,e/n)
shutil.copy2(repo/'diagnostics/pm12/cfd_simulator/analyze_reset_reference.py',p/'executed-analysis.py')
files=[f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts];m={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files};(e/'raw-manifest.json').write_text(json.dumps(m,indent=2)+'\n');a=e/'raw-data.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(a,'r:gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'archive-sha256.txt').write_text(hashlib.sha256(a.read_bytes()).hexdigest()+'  raw-data.tar.gz\n')
text='''# PM4 integrator repeat — 19 November2026

DUT PM12-K7-3A17A1B402212223, MCU1803, FPGAff2f746c; fitted CFDs1–4, CFD01 on PM4. Owner moved cables to4. DAC23/J6 on4 verified independently by signed integrator response; DAC01/J8 not exercised, existing ADC4 results retained.

Both integrators PASS_FUNCTIONAL at nominal20MHz, phaseDAC0, legacy before-str raw window. Coarse40, fine488 and independent validation64 transfer buffers coherent; no rejected or clipped buffers. Fine61points from2to8mV in100µV steps on DAC2, DAC3fixed2.048V. Model/source frozen before validation. Same reset-reference method/guards as PM3; no analysis changes.

| Bank | Selected delta | DAC2 / DAC3 | Independent returns(code) | Change at−5/+5mV(code) |
|---|---:|---|---|---|
| A |6.9mV|1.0309 /2.0480V|+0.192 /+0.303|+12.59 /−11.41|
| B |3.1mV|1.0271 /2.0480V|−0.167 /−0.162|+11.65 /−12.42|

Fits A−2406.78/B−2446.77code/V. Per-bank sampled-pair balance, not simultaneous A/B null or calibrated DC-current null. Separate diagnostic evidence; no retroactive selection into the older sealed integrator campaign contract.

No CPLD/FPGA/MCU programming, PLL profile change, ADC transfer/TDC/SMU repeat or production PDF generation. Final phase0, DAC01=1/1V,23=1.024/2.048V; fitted1–4 amps/bypass/monitors inhibited, TCA0; Kasli outputs retained. Archive read-back SHA256 verified. Integrator6 remains unresolved and needs a fitted simulator/cable move.

![Integrator4 balance and controls](final/integrator4.png)
'''
(e/'README.md').write_text(text)
prefix='Latest PM4 integrator repeat (2026-11-19): A/B PASS_FUNCTIONAL, nominal20MHz/phase0/before-str.100µV fine scan and independent±5mV/return controls pass; no rejected/clipped buffers. Separate reset-reference diagnostic, old selections unchanged. Final baseline restored, no programming. Integrator6 remains unresolved.\n[PM4 evidence](LINK).\n\n'
for f,link in [(repo/'README.md','diagnostics/pm12/acceptance/evidence-integrator04-20261119/README.md'),(repo/'diagnostics/pm12/acceptance/ACTIVE_CAMPAIGN.md','evidence-integrator04-20261119/README.md'),(Path('/home/codex-hil/FIT_PM_FW_uPC/docs/pm12_current_hardware_state.md'),str(e/'README.md'))]:f.write_text(prefix.replace('LINK',link)+f.read_text())
f=Path('/srv/codex-hil-nvme/pm12-campaigns/active.json');d=json.loads(f.read_text());d['status']='PM4 integrators A/B PASS_FUNCTIONAL in reset-reference diagnostic. Final baseline restored, no programming. Integrator6 unresolved.';d['latest_evidence']=str(e);d['latest_results']={'integrator_status':s['status'],'fits':s['fits'],'validation':s['validation'],'old_selections_changed':False};d['verified_connections']={'integrator':'DAC23/J6 verified on4 by signed response','ADC':'DAC01/J8 on4 assumed, not exercised this turn'};d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();f.write_text(json.dumps(d,indent=2)+'\n');print('archive verified',len(files))
