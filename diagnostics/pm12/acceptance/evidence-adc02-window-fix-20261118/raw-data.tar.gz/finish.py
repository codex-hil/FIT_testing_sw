import subprocess,sys,json
from pathlib import Path
p=Path(__file__).resolve().parent
try:
 subprocess.run(['/srv/codex-hil-nvme/tool-venvs/fit-measurements/bin/python',str(p/'register_v2.py')],check=True)
 subprocess.run(['/srv/codex-hil-nvme/tool-venvs/fit-measurements/bin/python',str(p/'plot_adc.py')],check=True)
finally:
 with (p/'final-cleanup-console.txt').open('w') as f:r=subprocess.run(['/home/codex-hil/kasli-diot-bringup/.venv/bin/python',str(p/'cleanup.py')],stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError('Final cleanup failed')
