import json,sys
from pathlib import Path
PM=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path.insert(0,str(PM/'acceptance'))
from campaign_adapters import adc
from campaign import Campaign
base=Path('/srv/codex-hil-nvme/pm12-ch02-window-fix-20261118');ctx=json.loads((base/'campaign-context.json').read_text());c=Campaign(ctx['root'])
results={}
for kind in ['adc-dc','adc-lines']:
 out=base/'receipts-standard'/kind
 receipt=adc(base/'adc-lines-standard',out,ctx['root'],ctx['batch'],kind)
 try:record=c.record(ctx['batch'],out);results[kind]=dict(status=receipt['status'],record=record)
 except ValueError as error:results[kind]=dict(status=receipt['status'],registration_error=str(error))
(base/'adc-standard-registration.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
