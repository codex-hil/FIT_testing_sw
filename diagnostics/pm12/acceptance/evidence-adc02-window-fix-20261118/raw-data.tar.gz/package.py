from pathlib import Path
import json,shutil,tarfile,hashlib,datetime
p=Path(__file__).resolve().parent;repo=Path('/home/codex-hil/fit-testing-publish');e=repo/'diagnostics/pm12/acceptance/evidence-adc02-window-fix-20261118';e.mkdir(exist_ok=False)
r=json.loads((p/'registration-v2.json').read_text());assert all(x['status']=='PASS' for x in r['results'].values());safe=json.loads((p/'final-safe.json').read_text());assert safe['pass_'];raw=json.loads((p/'adc-lines-standard/raw-validation.json').read_text());assert raw['pass'] and raw['captures']==514
summary={'board_uid':'PM12-K7-3A17A1B402212223','channel':2,'adc_dc':'PASS','adc_lines':'PASS','sample_window':'str-rise','phase_code':32768,'validated_captures':514,'raw_words':raw['raw_words'],'all_strobe_periods':4,'cpld_programmed':False,'final_safe':True,'old_campaign_selection_changed':False,'registration':r};(e/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for n in ['adc2.png','adc2.pdf','plot_adc.py','decoder-tests.txt','campaign-tests.txt','final-safe.json','registration-v2.json']:shutil.copy2(p/n,e/n)
for k in ['adc-dc','adc-lines']:
 (e/k).mkdir()
 for n in ['campaign-result.json','validation.json']:shutil.copy2(p/'receipts-v2'/k/n,e/k/n)
files=[f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts];m={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files};(e/'raw-manifest.json').write_text(json.dumps(m,indent=2)+'\n');a=e/'raw-data.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(a,'r:gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'archive-sha256.txt').write_text(hashlib.sha256(a.read_bytes()).hexdigest()+'  raw-data.tar.gz\n')
(e/'README.md').write_text('''# ADC2 window correction — 18 November2026

Board PM12-K7-3A17A1B402212223, MCU1803, FPGAff2f746c, CFD03 on PM2. Full ADC A/B transfer and sampled12-bit/11-adjacent-pair tests PASS with explicit str-rise window at phaseDAC32768. Independent reconstruction validates514buffers/2105344raw words, exact histograms/tags, contiguous generations, STR period4 throughout and no selected-word disagreement. Acquisition also retains the final zero control.

The corrected decoder compares data at observed STR rise to the preceding sample. Both must agree; wrong size/tags/reserved bits, missing/extra STR edges, excessive drift, pulse widths and any data disagreement remain errors. Legacy before-str remains the default for existing callers. New acquisition records sample_window; validators and ADC receipt FFT/time extraction use that same policy. Receipts carry a separate v2 method, never silently reinterpreting older data. No retries or data deletion within the successful scan.

An earlier corrected-window attempt at phase16384 stopped after74buffers with12unstable positions; it is retained unchanged. Three-point calibration did not cover its entire voltage range. This result supports32768 for this channel/setup, not universal phase suitability. Old phase0/16384/32768 failures and144buffer diagnostic remain in their respective evidence folders.

Software tests:13decoder tests (including all3real rejected buffers and a deliberately unstable later sample) plus26campaign tests PASS in the appropriate environments. Initial campaign test invocation with system Python lacked plotting dependencies; the scientific venv run passed.

The attempted separate campaign was prepared after acquisition and correctly rejected the older identity receipt. No identity timestamps or campaign guards were modified. New-method receipts are raw-validated using the already-bound original fitting context, retained here but unselected in the old frozen campaign. A future v2 campaign must bind identity before its acquisitions. Failed registration logs remain archived; no old production selection changed.

No CPLD/FPGA/MCU programming or PLL profile changes. Final phase0, DAC01=1/1V,23=1.024/2.048V, fitted1–4 amps/bypass/monitors inhibited, TCA0; shared Kasli outputs unchanged. Final independent cleanup PASS. No production report regeneration. Archive files all read-back SHA256 verified.

To repeat the corrected acquisition, set and verify phase32768 before running the existing guarded adc_line_test.py with --sample-window str-rise. Exact phase preparation, parking, acquisition commands and cleanup scripts are archived; the option does not itself program the phase DAC.

![ADC2 after correction](adc2.png)
''')
prefix='Latest ADC2 corrected-window repeat (2026-11-18): A/B transfer and sampled12-bit/11-adjacent-pair tests PASS with str-rise at phase32768. Independent raw check514captures/2105344words, all STR intervals4. Separate v2 method receipts retained; old frozen campaign selections unchanged. Phase16384 corrected-window attempt still incomplete. Final baseline restored, no programming.\n[Window fix and evidence](LINK).\n\n'
for f,link in [(repo/'README.md','diagnostics/pm12/acceptance/evidence-adc02-window-fix-20261118/README.md'),(repo/'diagnostics/pm12/acceptance/ACTIVE_CAMPAIGN.md','evidence-adc02-window-fix-20261118/README.md'),(Path('/home/codex-hil/FIT_PM_FW_uPC/docs/pm12_current_hardware_state.md'),str(e/'README.md'))]:f.write_text(prefix.replace('LINK',link)+f.read_text())
f=Path('/srv/codex-hil-nvme/pm12-campaigns/active.json');d=json.loads(f.read_text());d['status']='ADC2 corrected window/phase32768 full repeat PASS; v2 receipts retained unselected in old campaign. Final phase0 baseline restored, no programming.';d['latest_evidence']=str(e);d['latest_results']=summary;d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();f.write_text(json.dumps(d,indent=2)+'\n');print('archive verified',len(files))
