import json,sys
from pathlib import Path
p=Path(__file__).resolve().parent;sys.path.insert(0,'/home/codex-hil/fit-testing-publish/diagnostics/pm12/acceptance')
from campaign_adapters import adc
ctx=json.loads((p/'campaign-context.json').read_text());results={}
for kind in ['adc-dc','adc-lines']:
 out=p/'receipts-v2'/kind;r=adc(p/'adc-lines-standard',out,ctx['root'],ctx['batch'],kind);results[kind]={'status':r['status'],'method':r['protocol']['method'],'selected':False}
(p/'registration-v2.json').write_text(json.dumps({'results':results,'selection_status':'New-method receipts validated, not selected into old frozen campaign. New campaign preparation after capture correctly rejected old identity; no timestamps or guards changed.','original_identity_context':ctx},indent=2)+'\n');print(json.dumps(results))
