import sys,json
from pathlib import Path
PM=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path.insert(0,str(PM/'acceptance'))
from campaign import initialize,Campaign,read,write
from campaign_adapters import adc
p=Path(__file__).resolve().parent;prior=Path('/srv/codex-hil-nvme/pm12-campaigns/PM12-K7-3A17A1B402212223/four-cfd-clock40-20261117');root=prior.parent/'adc-str-rise-v2-20261118';spec=read(prior/'protocol.json');spec['name']='ADC str-rise-v2 window, separate acquisition epoch';spec['tests']=[t for t in spec['tests'] if t['id'] in ['adc-dc','adc-lines']];write(p/'protocol-v2.json',spec)
initialize(root,'PM12-K7-3A17A1B402212223','1803',p/'protocol-v2.json');c=Campaign(root);b=c.prepare(1,mapping={'1':'CFD04','2':'CFD03','3':'CFD02','4':'CFD01'},station=p/'station.json');c.bind_identity(b['id'],Path('/srv/codex-hil-nvme/pm12-ch02-20261118/identity/identity.json'),'Same fitting and USB2; retained actual identity receipt from before initial acquisition, not a new identity timestamp. FPGA/MCU live guards repeated at scan start.')
results={}
for kind in ['adc-dc','adc-lines']:
 out=p/'receipts-v2'/kind;r=adc(p/'adc-lines-standard',out,root,b['id'],kind);results[kind]={'status':r['status'],'record':c.record(b['id'],out)}
write(p/'registration-v2.json',dict(root=str(root),batch=b['id'],results=results));print(json.dumps(results,indent=2))
