from pathlib import Path
import sys,json,contextlib,os,subprocess,struct,statistics,time
repo=Path('/home/codex-hil/fit-testing-publish');P=repo/'diagnostics/pm12';sys.path[:0]=[str(P/'acceptance'),str(P/'cfd_simulator'),str(P/'ipbus_adc'),'/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire,ENV
from station import console
from pm12_console_regression import capture
from phase_scan import ConsoleDAC
from integrator_analysis import integration_pair
from adc_decode import decode
root=Path(__file__).parent.parent;out=root/'batches/ch05-08-attempt001/working/ch06/phase-diagnostic';out.mkdir();records=[];summary=[]
with contextlib.ExitStack()as st:
 locks={str((Path.home()/'.cache'/(n+'.lock')).resolve()):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock'))).fileno() for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001','esp32-6825dd4c49e4','lattice-VER00001'])};os.environ[ENV]=json.dumps(locks)
 def setphase(code):
  with console(dict(uart='/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller-if00-port0'))as u:ConsoleDAC(u,6,capture,records.append).set_code(code)
  (out/'console.json').write_text(json.dumps(records,indent=2)+'\n');time.sleep(.2)
 try:
  for code in [16384,32768,49152,65535]:
   setphase(code);dest=out/f'phase{code:05d}';cmd=[sys.executable,str(P/'cfd_simulator/integrator_scan.py'),'--afe','6','--expected-build','ff2f746c','--dac-channels','2','3','--base','1.024','2.048','--offsets','-.01','0','.01','.02','--repeats','2','--out',str(dest)]
   with(out/f'phase{code:05d}-console.txt').open('w')as log:subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True,pass_fds=tuple(locks.values()))
   d=json.loads((dest/'status.json').read_text());points=[]
   for pt in d['points']:
    b={}
    for bank in [0,1]:
     vals=[];errors=[]
     for cap in pt['captures']:
      if cap['bank']!=bank:continue
      try:vals.append(integration_pair(decode(struct.unpack('<4096H',(dest/cap['file']).read_bytes()),bank)[0])['mean_change'])
      except ValueError as ex:errors.append(str(ex))
     b[str(bank)]=dict(change=statistics.mean(vals)if vals else None,errors=errors)
    points.append(dict(offset=pt['offset_V'],banks=b))
   summary.append(dict(code=code,points=points));(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(code,points,flush=True)
 finally:setphase(0);(out/'restoration.json').write_text(json.dumps(dict(DAC_A_commanded=0,hardware_readback=False))+'\n')
