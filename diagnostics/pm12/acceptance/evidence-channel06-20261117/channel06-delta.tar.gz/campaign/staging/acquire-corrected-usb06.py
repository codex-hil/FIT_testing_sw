from pathlib import Path
import sys,json,subprocess,statistics,datetime
repo=Path('/home/codex-hil/fit-testing-publish');P=repo/'diagnostics/pm12';root=Path(__file__).parent.parent;stage=root/'staging';work=root/'batches/ch05-08-attempt001/working/ch06';py=sys.executable
s=(stage/'preflight-ch06.py').read_text().replace('working/ch06/preflight','working/ch06/corrected-usb-preflight');(stage/'ch06-corrected-usb-preflight.py').write_text(s)
def run(label,cmd):
 with(stage/('ch06-'+label+'-console.txt')).open('w')as log:subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(label,'COMPLETE',flush=True)
run('corrected-usb-preflight',[py,str(stage/'ch06-corrected-usb-preflight.py')])
common=['--afe','6','--expected-build','ff2f746c','--dac-channels','0','1','--integrator-dac-channels','2','3','--mux-select-map','0','1']
probes=[]
for inhibited in [False,True]:
 label='corrected-usb-probe-'+('inhibited'if inhibited else'active');cmd=[py,str(P/'cfd_simulator/adc_dc_scan.py'),*common,'--probe','--out',str(work/label)]
 if inhibited:cmd+=['--bypass-inhibited']
 run(label,cmd);r=json.loads((work/label/'status.json').read_text());assert r['pass'];gains=[]
 for bank in [0,1]:
  pts=sorted([v for v in r['measurements']if v['bank']==bank and v['injection_bank']==bank],key=lambda v:v['diff_setpoint_v']);gains.append((pts[-1]['raw_mean']-pts[0]['raw_mean'])/.04)
 probes.append(gains)
assert all(g < -500 for g in probes[0]) and max(abs(g)for g in probes[1])<.1*min(abs(g)for g in probes[0]),probes
(work/'corrected-usb-route-verified.json').write_text(json.dumps(dict(measured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),direct_adc_dac_channels=[0,1],integrator_dac_channels=[2,3],mux_select_map=[0,1],active_gain_code_per_V=probes[0],inhibited_gain_code_per_V=probes[1],operator_note='Both USB moved7->6; owner confirmed Juz'),indent=2)+'\n')
run('corrected-usb-adc-full',[py,str(P/'cfd_simulator/adc_line_test.py'),'--acquire',*common,'--points','257','--out',str(work/'adc-corrected-usb')])
s=(stage/'integrator-ch06-controller.py').read_text().replace("work/'adc-full", "work/'adc-corrected-usb").replace("target=work/'integrator'", "target=work/'integrator-corrected-usb'")
(stage/'integrator-corrected-usb06-controller.py').write_text(s);run('corrected-usb-integrator',[py,str(stage/'integrator-corrected-usb06-controller.py')])
(work/'corrected-usb-analog-completed.json').write_text(json.dumps(dict(pass_=True,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),adc='adc-corrected-usb',integrator='integrator-corrected-usb',route='corrected-usb-route-verified.json'),indent=2)+'\n')
