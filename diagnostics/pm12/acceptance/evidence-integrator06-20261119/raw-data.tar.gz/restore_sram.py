from pathlib import Path
import contextlib,sys,json,hashlib,subprocess,time
PM=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(PM/'acceptance'),str(PM),str(PM/'ipbus_adc'),'/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from station import read_dna,jtag_command,console
from lease import acquire
from test_board import payload
from pm12_console_regression import capture
from pm12_power import wait_power_good
from client import Client
p=Path(__file__).resolve().parent;out=p/'sram-restore';out.mkdir();cfg=json.loads((p/'station.json').read_text());cfg['jtag_workspace']=str(p/'jtag-work');bit=Path('/srv/codex-hil-nvme/pm12-rx-clock-counter-20261115/candidate-v2/pm12_ipbus_adc.bit');sha=hashlib.sha256(bit.read_bytes()).hexdigest();assert sha=='28fb5747bafe575455bff8bf91484c8ebb5303ea18d3e0a0925fdb0c4283d0b2';r={'bit_sha256':sha,'volatile_sram_only':True}
with contextlib.ExitStack() as st:
 for n in sorted(cfg['run_leases']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 u=st.enter_context(console(cfg));r['power']=wait_power_good(u,capture);r['serial']=capture(u,'RS');assert '1803' in r['serial']['reply']
 dna=read_dna(cfg,out);r['dna']=dna;assert dna=='3A17A1B402212223';print('DNA verified',dna,flush=True)
 script=(PM/'adc/tools/load_fpga.tcl').read_text().replace('source [file join [file dirname [info script]] common.tcl]','source '+str(PM/'adc/tools/common.tcl')).replace('0x504dad01','0x504d5a04');(out/'load.tcl').write_text(script);bits=payload(bit,out/'payload.hex')
 with jtag_command(cfg,out) as prefix:
  with (out/'load.log').open('w') as log:subprocess.run(prefix+['-mode','batch','-nolog','-nojournal','-notrace','-source',str(out/'load.tcl'),'-tclargs',cfg['jtag_cable'],cfg.get('hw_server','localhost:3121'),str(out/'payload.hex'),str(bits)],stdout=log,stderr=subprocess.STDOUT,timeout=300,check=True,start_new_session=True)
 assert 'LOAD_PASS' in (out/'load.log').read_text();print('SRAM load complete',flush=True)
 c=Client();st.callback(c.close)
 for attempt in range(5):
  try:r['fpga']=c.read(0,3);break
  except TimeoutError:
   if attempt==4:raise
 assert r['fpga']==[0x504d1202,0x10002,0xff2f746c];r['serial_after']=capture(u,'RS');r['pass_']=True
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print('RESTORE_PASS',flush=True)
