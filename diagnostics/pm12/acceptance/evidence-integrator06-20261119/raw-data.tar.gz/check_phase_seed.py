import sys
from pathlib import Path
sys.argv=['analysis','--coarse','/srv/codex-hil-nvme/pm12-ch06-20261119/coarse','--fine','/srv/codex-hil-nvme/pm12-ch06-20261119/fine','--phase-code','0','--out','/srv/codex-hil-nvme/pm12-ch06-20261119/unused']
s=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12/cfd_simulator/analyze_reset_reference.py').read_text();g={'__file__':'/home/codex-hil/fit-testing-publish/diagnostics/pm12/cfd_simulator/analyze_reset_reference.py'};exec(s.split('training_phases={}')[0],g)
import math,statistics,json
print('models',g['models'])
for b in [0,1]:
 model=g['models'][str(b)];bad=[]
 for point in g['reports']['fine']['points']:
  delta=point['actual_requested_offset_V'];pred=[v+s*delta for v,s in zip(model['reset_intercepts'],model['reset_slopes'])]
  for cap in point['captures']:
   if cap['bank']!=b:continue
   m=g['means']('fine',cap);scores=[math.sqrt(sum((m[(s+2+i)%4]-pred[i])**2 for i in range(2))/2) for s in range(4)];o=sorted(range(4),key=lambda i:scores[i])
   if scores[o[0]]>5 or scores[o[1]]-scores[o[0]]<3:bad.append({'delta':delta,'m':m,'scores':scores,'pred':pred,'file':cap['file']})
 print('bank',b,'bad',len(bad),'examples',bad[:2])
for b in [0,1]:
 model=g['models'][str(b)];xx=[];yy=[]
 for point in g['reports']['fine']['points']:
  delta=point['actual_requested_offset_V']
  if delta>.0065:continue
  pred=[v+s*delta for v,s in zip(model['reset_intercepts'],model['reset_slopes'])]
  for cap in point['captures']:
   if cap['bank']!=b:continue
   m=g['means']('fine',cap);scores=[math.sqrt(sum((m[(s+2+i)%4]-pred[i])**2 for i in range(2))/2) for s in range(4)];o=sorted(range(4),key=lambda i:scores[i]);s=o[0];assert scores[s]<=5 and scores[o[1]]-scores[s]>=3
   xx.append(delta);yy.append(m[(s+1)%4]-m[s])
 fit=statistics.linear_regression(xx,yy);print('PRELIMINARY',b,-fit.intercept/fit.slope,fit.slope)
