from pathlib import Path
import json,hashlib,tarfile,shutil,datetime
p=Path(__file__).resolve().parent;repo=Path('/home/codex-hil/fit-testing-publish');e=repo/'diagnostics/pm12/acceptance/evidence-integrator06-20261119';e.mkdir(exist_ok=False)
s=json.loads((p/'final/summary.json').read_text());safe=json.loads((p/'final-safe.json').read_text());assert s['status']=='PASS_FUNCTIONAL' and safe['pass_'] and not s['analysis_rejected'];assert set(safe['gpio'])=={'3','4','5','6'}
for n in ['final','focused-analysis']:shutil.copytree(p/n,e/n)
for n in ['fine-command.json','fine-focused-command.json','validation-command.json','analysis-frozen-before-validation.json','final-safe.json','link-status.json','seed-analysis-console.txt']:shutil.copy2(p/n,e/n)
shutil.copy2(repo/'diagnostics/pm12/cfd_simulator/analyze_reset_reference.py',p/'executed-analysis.py')
files=[f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts and 'jtag-work' not in f.parts and f.name!='payload.hex'];m={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files};(e/'raw-manifest.json').write_text(json.dumps(m,indent=2)+'\n');a=e/'raw-data.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(a,'r:gz') as t:
 for n,h in m.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
(e/'archive-sha256.txt').write_text(hashlib.sha256(a.read_bytes()).hexdigest()+'  raw-data.tar.gz\n')
(e/'README.md').write_text('''# PM6 integrator repeat — 19 November2026

Owner correction: CFD simulators fitted on3,4,5,6; USB on6. Moved simulator identities and RJ45 mapping not verified in this analog test. DAC23/J6→physical6 independently confirmed by signed response; DAC01/J8 not exercised. Existing ADC6 evidence retained.

Initial PM Ethernet unavailable; Kasli bridge operational, MCU1803/PGOOD/PRIMARY PLL healthy but console FPGA not ready. JTAG DNA verified3A17A1B402212223, USERCODEffffffff. Exact known ff2f746c SRAM image restored, SHA25628fb5747bafe575455bff8bf91484c8ebb5303ea18d3e0a0925fdb0c4283d0b2. IPbus identity restored. No FPGA Flash, MCU, CPLD or PLL profile programming. Generated payload.hex and JTAG extraction workspace excluded from archive; hash, loader and full logs retained.

After moving modules, an inhibit readback failed because relevant expander pins were still inputs. Cleanup now sets inhibit latches before making only GPA7/GPA3/GPB5 outputs, preserving other directions. All fitted3–6 inhibit readbacks verified. Initial coarse acquisition before explicit phase confirmation retained separately; definitive coarse repeated after acknowledged phase0.

Both integrators PASS_FUNCTIONAL at nominal20MHz, phase0/before-str raw window. Full coarse40buffers, focused fine328 and independent validation64 coherent, unclipped and unambiguous. Earlier wide fine488buffers was raw-coherent but reset-reference registration became ambiguous at larger positive bankB offsets. No thresholds changed: that wide analysis failure and buffers retained. Preliminary unambiguous low-range data localized roots; new focused41-point2.5..6.5mV scan at100µV steps performed before separate validation. Model/source frozen before returns; no final analysis rejections.

| Bank | Selected delta | DAC2 / DAC3 | Independent returns(code) | Change at−5/+5mV(code) |
|---|---:|---|---|---|
| A |5.1mV|1.0291 /2.0480V|−0.283 /−0.482|+12.31 /−11.91|
| B |4.3mV|1.0283 /2.0480V|−0.245 /+0.171|+11.61 /−12.65|

Fits A−2535.07/B−2384.00code/V. Per-bank sampled-pair balance, not simultaneous A/B null or calibrated current null. This separate diagnostic functional method does not retroactively alter the old sealed integrator campaign selections. Earlier channel6 ambiguity was not labelled a repaired physical fault; no soldering/component change is established here.

Final phase0, DAC01=1/1V,23=1.024/2.048V; all fitted3–6 amps/bypass/monitors inhibited, TCA0, Kasli outputs retained. Final cleanup PASS. No SMU/TDC/ADC-transfer repeat or production PDF generation. Archive files read-back SHA256 verified.

Previously unresolved integrators3/4/6 now each have separate successful functional fine-scan/return evidence. Whole-board production release still needs the evidence/coverage audit described in the active workflow.

![Integrator6 balance and controls](final/integrator6.png)
''')
prefix='Latest PM6 integrator repeat (2026-11-19): A/B PASS_FUNCTIONAL, phase0/before-str/nominal20MHz.100µV focused scan and independent±5mV/return controls pass. Wide registration ambiguity retained; no relaxed thresholds. Corrected fitting3–6/USB6. Exact ff2f746c restored to SRAM after not-ready state; no Flash/MCU/CPLD/PLL writes. Final baseline/inhibition3–6 verified. Previously unresolved integrators3/4/6 now have successful diagnostic evidence; whole-board audit still required.\n[PM6 evidence](LINK).\n\n'
for f,link in [(repo/'README.md','diagnostics/pm12/acceptance/evidence-integrator06-20261119/README.md'),(repo/'diagnostics/pm12/acceptance/ACTIVE_CAMPAIGN.md','evidence-integrator06-20261119/README.md'),(Path('/home/codex-hil/FIT_PM_FW_uPC/docs/pm12_current_hardware_state.md'),str(e/'README.md'))]:f.write_text(prefix.replace('LINK',link)+f.read_text())
f=Path('/srv/codex-hil-nvme/pm12-campaigns/active.json');d=json.loads(f.read_text());d['status']='PM6 A/B PASS_FUNCTIONAL in reset-reference diagnostic, old selections unchanged. Fitting3–6/USB6. Exact SRAM restored; final baseline and fitted3–6 inhibition verified. Whole-board coverage audit pending.';d['latest_evidence']=str(e);d['latest_results']={'integrator_status':s['status'],'fits':s['fits'],'validation':s['validation'],'old_selections_changed':False};d['verified_connections']={'integrator':'DAC23/J6 verified on6 by signed response','ADC':'DAC01/J8 on6 assumed, not exercised','fixture_and_RJ45_mapping':'not independently verified for moved3–6 fitting'};d['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();f.write_text(json.dumps(d,indent=2)+'\n');print('archive verified',len(files))
