from pathlib import Path
import sys,contextlib,json
PM=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(PM/'acceptance'),str(PM/'ipbus_adc'),'/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire
from station import console
from pm12_console_regression import capture
from pm12_power import wait_power_good
from client import Client
r={};p=Path(__file__).resolve().parent;cfg=json.loads((p/'station.json').read_text())
with contextlib.ExitStack() as st:
 for n in sorted(cfg['run_leases']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 u=st.enter_context(console(cfg));r['power']=wait_power_good(u,capture);r['serial']=capture(u,'RS')
 for host in ['192.168.2.241','192.168.2.240']:
  c=Client(host);st.callback(c.close)
  try:
   r[host]={'id':c.read(0,3)}
   if host.endswith('241'):r[host].update(bridge=[c.read(a//4)[0] for a in [0x120,0x13c,0x144,0x150]])
  except Exception as e:r[host]={'error':repr(e)}
(p/'link-status.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
