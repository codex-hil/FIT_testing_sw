import subprocess,json
from pathlib import Path
repo=Path('/home/codex-hil/fit-testing-publish');work=Path(__file__).parent.parent/'batches/ch09-12-attempt001/working/ch09';py='/home/codex-hil/kasli-diot-bringup/.venv/bin/python'
assert json.loads((work/'preflight/status.json').read_text())['pass_'], 'Preflight must pass before acquisition'
with (work/'adc-probe-console.txt').open('w') as log:
 subprocess.run([py,str(repo/'diagnostics/pm12/cfd_simulator/adc_dc_scan.py'),'--afe','9','--expected-build','ff2f746c','--board-serial','1803','--dac-channels','0','1','--probe','--out',str(work/'adc-probe')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
r=json.loads((work/'adc-probe/status.json').read_text());assert r['pass']
for bank in [0,1]:
 rows=sorted([p for p in r['measurements'] if p['bank']==bank and p['injection_bank']==bank],key=lambda p:p['diff_setpoint_v'])
 delta=rows[-1]['raw_mean']-rows[0]['raw_mean'];assert delta < -20,(bank,delta)
 print('Probe bank',bank,'delta codes',delta,flush=True)
with (work/'adc-full-console.txt').open('w') as log:
 subprocess.run([py,str(repo/'diagnostics/pm12/cfd_simulator/adc_line_test.py'),'--acquire','--afe','9','--expected-build','ff2f746c','--board-serial','1803','--dac-channels','0','1','--points','257','--out',str(work/'adc-full')],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
print('CH09_ADC_COMPLETE',flush=True)
