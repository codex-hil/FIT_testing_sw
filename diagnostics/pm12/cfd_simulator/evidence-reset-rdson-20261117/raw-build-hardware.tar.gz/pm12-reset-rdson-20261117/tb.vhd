library ieee; use ieee.std_logic_1164.all;
entity tb is end; architecture sim of tb is
signal clk: std_logic := '0'; signal a,b: std_logic_vector(16 downto 0);
begin
clk <= not clk after 6 ns;
u: entity work.adc_mux port map(clk,'0','0','0',x"123",x"ABC",a(12 downto 0),a(13),a(14),a(15),a(16),open);
v: entity work.adc_mux_original port map(clk,'0','0','0',x"123",x"ABC",b(12 downto 0),b(13),b(14),b(15),b(16),open);
process begin wait for 1 ns;
for i in 0 to 200 loop
assert a(15)='1' report "Reset B not held high" severity failure;
assert a(14 downto 0)=b(14 downto 0) and a(16)=b(16) report "Unaffected outputs differ" severity failure;
wait for 3 ns;
end loop;
report "CLOCK_AND_MUX_PRESERVATION_PASS"; std.env.stop; wait; end process;
end;
