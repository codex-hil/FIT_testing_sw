set -eu
cd /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/rdson-20261117
set +u
source "$ISE_SETTINGS" "$(dirname "$ISE_SETTINGS")"
set -u
for name in program restore verify-original; do impact -batch "$name.cmd" > "$name-export.log" 2>&1; done
