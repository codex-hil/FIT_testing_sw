import contextlib,datetime,json,sys
from pathlib import Path
PM=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12')
sys.path[:0]=[str(PM/'acceptance'),str(PM/'cfd_simulator'),str(PM/'ipbus_adc'),'/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from campaign import initialize,Campaign,read,write
from station import console,read_dna
from lease import acquire
from pm12_console_regression import capture
from pm12_power import wait_power_good
from channel_settings import require_serial_reply
from client import Client
base=Path('/srv/codex-hil-nvme/pm12-campaigns/PM12-K7-3A17A1B402212223')
root=base/'reset-standard-20261117'
previous=base/'four-cfd-clock40-20261117/batches/ch01-04-attempt001/station.json'
cfg=read(previous)
initialize(root,cfg['board_uid'],cfg['board_serial'])
c=Campaign(root);batch=c.prepare(1,mapping={'1':'CFD04','2':'CFD03','3':'CFD02','4':'CFD01'},station=previous)
station=root/'batches'/batch['id']/'station.json'
cfg=read(station);cfg['stimulated_channel']=2
for ch in cfg['channels']:cfg['channels'][ch]['integrator_connected']=ch=='2'
write(station,cfg)
out=root/'identity-live';out.mkdir()
with contextlib.ExitStack() as st:
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 u=st.enter_context(console(cfg));pg=wait_power_good(u,capture)
 mcu=capture(u,'RS');require_serial_reply(mcu['reply'],str(cfg['board_serial']))
 client=Client();st.callback(client.close);fpga=client.read(0,3);assert fpga==[0x504d1202,0x10002,0xff2f746c]
 dna=read_dna(cfg,out);assert 'PM12-K7-'+dna==cfg['board_uid']
 receipt=dict(status='PASS',identity=dict(uid=cfg['board_uid'],mcu_eeprom_serial=str(cfg['board_serial']),observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),fpga_dna=dna,fpga_identity=fpga,pgood=pg,mcu=mcu))
 write(out/'identity.json',receipt)
c.bind_identity(batch['id'],out/'identity.json','Existing owner-confirmed fitting1-4; current J6 discovered on physical2; fixture03, slot7 port2. No cable move declared since preceding measurement.')
print(root,batch['id'],flush=True)
