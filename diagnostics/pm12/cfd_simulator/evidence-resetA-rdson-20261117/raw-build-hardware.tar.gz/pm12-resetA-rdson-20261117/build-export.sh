set -eu
cd /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/resetA-rdson-20261117
PM12_ISE_SETTINGS="$ISE_SETTINGS" PM12_ISE_COMPAT=/nonexistent bash cpld/build.sh > build.log 2>&1
set +u
source "$ISE_SETTINGS" "$(dirname "$ISE_SETTINGS")"
set -u
for n in program restore verify-original; do impact -batch "$n.cmd" > "$n-export.log" 2>&1; done
