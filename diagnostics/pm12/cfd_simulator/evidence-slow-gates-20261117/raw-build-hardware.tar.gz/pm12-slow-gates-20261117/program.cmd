setMode -bs
setCable -port svf -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/program.svf
addDevice -p 1 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 2 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 3 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 4 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 5 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 6 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 7 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 8 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 9 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 10 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 11 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 12 -file /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117/cpld/build/design.jed
addDevice -p 13 -file /srv/nvme-fast-2/toolchains/ise/14.7/ISE_DS/ISE/kintex7/data/xc7k160t_ffg676.bsd
program -p 2 -e -v
quit
