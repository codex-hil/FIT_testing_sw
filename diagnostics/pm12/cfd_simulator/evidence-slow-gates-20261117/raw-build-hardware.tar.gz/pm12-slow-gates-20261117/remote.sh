set -eu
cd /srv/nvme-fast-4/remote-builds/coolrunner2-recovery/slow-gates-20261117
mkdir -p sim; cd sim
ghdl -a --std=08 ../original.vhd ../cpld/adc_mux.vhd ../tb.vhd
ghdl -e --std=08 tb
ghdl -r --std=08 tb --assert-level=error > ../simulation.log
cd ..
PM12_ISE_SETTINGS="$ISE_SETTINGS" PM12_ISE_COMPAT=/nonexistent bash cpld/build.sh > build.log 2>&1
set +u
source "$ISE_SETTINGS" "$(dirname "$ISE_SETTINGS")"
set -u
for n in program restore verify-original; do impact -batch "$n.cmd" > "$n-export.log" 2>&1; done
